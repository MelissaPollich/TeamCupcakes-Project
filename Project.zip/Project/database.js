var pgp = require('pg-promise')();

const dbConfig = {
   user: 'postgres',
   host: '127.0.0.1',
   port: '5432',
   database: 'teamcupakes', //idk why i couldn't create weatherdatabase with sysadmin role
   password: 'Marley81796!' // Fill in your PostgreSQL password here. Use empty string
                // if you did not set a password
};

var db = pgp(dbConfig);

module.exports = db;